=== WeightLossAffordable Core (v2.0) ===
Requires at least: 6.6
Requires PHP: 7.4
Stable tag: 2.0.0
License: GPL-2.0-or-later

Companion plugin providing all 11 Preview-Identical Free Elementor Widgets, Single-Page Live EN/ES Translator Engine + Admin Overrides, AJAX General Inquiry Form, Custom Post Types (Services, Treatments, Packages, Reviews, Team), and One-Click Single-Site Demo Importer (18 single canonical pages — zero duplicate copy pages).
