=== WeightLossAffordable Theme (v2.0) ===

100% Preview-Identical WordPress theme with Straw Luxury palette, Fraunces + Manrope typography, full scroll/tilt motion choreography, interactive 4-Stage Journey Board, interactive Guide Explorer + Modal Reader, AJAX General Inquiry Form, Free Elementor widgets, and built-in Single-Page Live Translator (EN / ES — zero duplicate copy pages).

QUICK INSTALL:
1. Upload & activate weightloss-affordable-theme.zip in Appearance -> Themes -> Add New -> Upload Theme.
2. Upload & activate weightloss-affordable-core.zip in Plugins -> Add New -> Upload Plugin.
3. Install & activate the free Elementor plugin (Elementor Pro is NOT required).
4. Visit WeightLoss Setup -> Demo Import and click "Import Complete 100% Preview Website".
5. Optional: Visit WeightLoss Setup -> Live Translator to set default site language (EN or ES) or add custom phrase overrides.
